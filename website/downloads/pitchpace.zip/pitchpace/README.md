# PitchPace

**Train like you mean it.** A private, local-first training tracker for soccer
and track athletes. Log every session, watch your training load stay in the safe
zone, and get an AI coach that plans your week, meals and recovery — using **your
own API key** (or a fully offline local model).

Your data lives in a local SQLite file. Your AI key lives in your browser. There
is no PitchPace cloud and no account.

> **New here?** Read **[`GETTING_STARTED.md`](GETTING_STARTED.md)** — a plain-English,
> step-by-step tutorial for starting the app and opening it in your browser, with
> fixes for the common "this site can't be reached" message.

---

## Features

- **Dashboard** — weekly load, an 8-week trend, and an acute:chronic workload
  ratio (ACWR) gauge to keep you out of the injury red zone.
- **Log Workout** — matches, runs, track sessions, gym lifts, weightlifting,
  calisthenics, plyometrics, cross-training, **boxing** and recovery — each
  activity type with its own tailored detail fields (sets/reps/load, intervals,
  rounds, pace, position, and more).
- **History** — search, filter and edit every session.
- **Training Plan / AI Coach / Nutrition & Recovery** — AI features that already
  know your profile, load and recent sessions.

## Requirements

- **Python 3.11+**
- **Node 20+** (only needed to build the UI; Node 22 recommended)

## Quick start (one command)

```bash
./start.sh
# Builds the React UI, then serves the whole app (UI + API) on one port:
#   → http://localhost:8000
```

### Or run in dev mode (hot reload)

```bash
./dev.sh
# Backend (FastAPI, auto-reload) on :8000
# Frontend (Vite, HMR) on :5181  ←  open this one
```

On first run the database is created automatically and starts empty — your stats
grow as you log sessions.

## Bring your own AI key (optional)

PitchPace's AI features work two ways:

1. **Claude (recommended).** Open **Settings** (the gear icon) and paste your
   Anthropic API key (`sk-ant-…`). It is stored **only in your browser** and sent
   directly to Anthropic. Usage is billed to your own Anthropic account.
2. **Local Ollama (no key, fully offline).** Install [Ollama](https://ollama.com),
   pull a model (e.g. `ollama pull llama3.2`), and PitchPace will use it
   automatically when no Claude key is set.

You can also set a server-side fallback key via the `ANTHROPIC_API_KEY`
environment variable (handy for a shared/hosted instance), but per-request keys
from the browser always take priority.

## Project structure

```
backend/    FastAPI + SQLite API (app/), requirements.txt, run.py
frontend/   React + Vite + Tailwind app (src/)
dev.sh      dev servers with hot reload
start.sh    one-command build + serve on a single port
Dockerfile  single-image build (UI + API) for container hosts
railway.toml Railway deploy config
```

## Deploy (optional)

PitchPace ships a `Dockerfile` that builds the UI and serves everything from
FastAPI on `$PORT`:

```bash
docker build -t pitchpace .
docker run -p 8000:8000 pitchpace      # → http://localhost:8000
```

**Railway:** create a project from this repo (it auto-detects the `Dockerfile`
and `railway.toml`). The included health check hits `/api/health`. The container
filesystem is ephemeral, so attach a volume at `/app/backend/data` if you want the
demo database to persist across deploys.

> Note: a public demo has no auth. Don't store private data in a shared instance.

## Privacy

Local-first by design: your sessions stay in `backend/data/pitchpace.db` and your
key stays in your browser. See the website's Privacy Policy and Terms for details.

## Configuration (env vars)

| Variable             | Default                  | Purpose                                  |
| -------------------- | ------------------------ | ---------------------------------------- |
| `PITCHPACE_PORT`     | `8000`                   | API/server port (when using `run.py`)    |
| `OLLAMA_BASE_URL`    | `http://localhost:11434` | Local Ollama endpoint                    |
| `OLLAMA_MODEL`       | `llama3.2`               | Local Ollama model name                  |
| `ANTHROPIC_API_KEY`  | _(unset)_                | Optional server-side fallback Claude key |

---

© 2026 PitchPace. Provided as-is, for personal training use. Not medical advice —
see the Terms. Not affiliated with Anthropic or Ollama.
